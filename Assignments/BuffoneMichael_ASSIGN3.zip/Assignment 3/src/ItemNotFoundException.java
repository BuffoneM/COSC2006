/*
 * Assignment 3
 * Michael Buffone
 * Oct 30th, 2019
 * 
 * Exception implemented by linked list
 */

public class ItemNotFoundException extends RuntimeException {
	
	public ItemNotFoundException(String s) {
		super(s);
	}

}
